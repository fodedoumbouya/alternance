package com.example.internship

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
